package com.ums.client;

import java.util.Scanner;

import com.ums.dao.impl.UserDaoImpl;
import com.ums.pojo.User;

public class UserClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		UserDaoImpl userdao = new UserDaoImpl();
		User user = new User();
		while (true) {
			System.out.println("*********************Welcome to our UserManagement System**********************");
			System.out.println("                    1) Register                                                ");
			System.out.println("                    2) Login                                                ");
			System.out.println("                    3) Forgot password                                          ");
			System.out.println("                    4) View Record                                            ");
			System.out.println("                    5) Exit                                                    ");
			System.out.println("*******************************************************************************");
			System.out.println("Enter your choice");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Hello there");
				user.setUid(100);
				System.out.println("Your Firstname :");
				user.setFirstName(sc.next());
				System.out.println("Your Lastname :");
				user.setLastName(sc.next());
				System.out.println("Your Email-Id :");
				user.setEmail(sc.next());
				System.out.println("Your Password :");
				user.setPassword(sc.next());
				userdao.register(user);
				break;
			case 2:
				System.out.println("Enter your email-id");
				String email = sc.next();
				System.out.println("Enter your password");
				String pass = sc.next();

				if (user.getUid() != 0) {
					boolean result = userdao.verifyUnAndPw(email, pass);
					if (result) {
						System.out.println("Welcome to our System");
					} else {
						System.out.println("Check your Email and Password");
					}
				} else {
					System.out.println("We don't have your record please register first");
				}
				break;
			case 3:
				System.out.println("Enter your email-id");
				email = sc.next();
				if (user.getUid() != 0) {
					userdao.forgotPassword(email);
				} else {
					System.out.println("We don't have your record please register first");
				}
				break;
			case 4:
				if (user.getUid() != 0) {
					System.out.println(user.getUid() + "\t" + user.getFirstName() + "\t" + user.getLastName() + "\t"
							+ user.getEmail() + "\t" + user.getPassword());
				} else {
					System.out.println("Please register first");
				}
				break;
			case 5:
				System.exit(0);
				break;
			default:
				System.out.println("Choose between 1-5");
			}

		}
	}

}
