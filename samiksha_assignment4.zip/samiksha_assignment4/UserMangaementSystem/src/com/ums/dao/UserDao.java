package com.ums.dao;

import com.ums.pojo.User;

public interface UserDao {
	void register(User user);
	
	boolean verifyUnAndPw(String email,String password);
	
	void forgotPassword(String email);
}
