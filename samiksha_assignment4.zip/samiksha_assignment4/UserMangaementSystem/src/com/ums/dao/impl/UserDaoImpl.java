package com.ums.dao.impl;

import java.util.ArrayList;
import java.util.Scanner;

import com.ums.dao.UserDao;
import com.ums.pojo.User;

public class UserDaoImpl implements UserDao {
	Scanner sc = new Scanner(System.in);

	@Override
	public void register(User user) {
		// TODO Auto-generated method stub
		ArrayList<User> al = new ArrayList<User>();
		al.add(user);
		System.out.println("User Successfully Added");
		System.out.println("UID\tFirstname\tLastname\tEmail-id\tPassword");
		for (User u : al) {
			System.out.println(u.getUid() + "\t" + u.getFirstName() + "\t" + u.getLastName() + "\t" + u.getEmail()
					+ "\t" + u.getPassword());
		}

	}

	@Override
	public boolean verifyUnAndPw(String email, String pass) {
		// TODO Auto-generated method stub
		String emailId = User.getEmail();
		String password = User.getPassword();
		if (emailId.equals(email) && password.equals(pass)) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public void forgotPassword(String email) {
		// TODO Auto-generated method stub
		System.out.println("Enter your new password");
		String pass = sc.next();
		User.setPassword(pass);
		System.out.println("Password changed successfully");
		
	}

}
