package com.pms.details;

import java.util.Scanner;

import com.pms.dao.impl.ProductDaoImpl;

public class ProductDetails {
	Scanner sc = new Scanner(System.in);
	ProductDaoImpl prodDao=new ProductDaoImpl();
	int productId;
	public void productMenu() {
		while (true) {
			System.out.println("*********************Product Menu*********************************************");
			System.out.println("                    1) Add Product                                          ");
			System.out.println("                    2) ViewAll Products                                          ");
			System.out.println("                    3) View Product                                          ");
			System.out.println("                    4) Update Product                                            ");
			System.out.println("                    5) Delete Product                                            ");
			System.out.println("                    6) Back                                                    ");
			System.out.println("******************************************************************************");
			System.out.println("Enter your choice");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				prodDao.addProduct();
				break;
			case 2:
				prodDao.viewAllProducts();
				break;
			case 3:
				System.out.println("Enter the product Id");
				productId=sc.nextInt();
				prodDao.viewProduct(productId);
				break;
			case 4:
				System.out.println("Enter the product Id");
				productId=sc.nextInt();
				prodDao.updateProduct(productId);
				break;
			case 5:
				System.out.println("Enter the product Id");
				productId=sc.nextInt();
				prodDao.deleteProduct(productId);
				break;
			case 6:
				AdminDetails adminDetails=new AdminDetails();
				adminDetails.adminMenu();
				break;
			default:
				System.out.println("Choose between 1-6");
			}

		}
	}

	public void customerMenuAdmin() {
		while (true) {
			System.out.println("*********************Customer Menu*********************************************");
			System.out.println("                    1) Add Customer                                          ");
			System.out.println("                    2) ViewAll Customers                                        ");
			System.out.println("                    3) View Customer                                          ");
			System.out.println("                    4) Update Customer                                           ");
			System.out.println("                    5) Delete Customer                                         ");
			System.out.println("                    6) Back                                                    ");
			System.out.println("***************************************************************************");
			System.out.println("Enter your choice");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				break;
			case 2:
				break;
			case 3:
				break;
			case 4:
				break;
			case 5:
				break;
			case 6:
				AdminDetails adminDetails=new AdminDetails();
				adminDetails.adminMenu();
				break;
			default:
				System.out.println("Choose between 1-6");
			}

		}
	}
}
