package com.pms.details;

import java.util.Scanner;

import com.pms.client.ProductClient;
import com.pms.dao.impl.ProductDaoImpl;

public class CustomerDetails {
	Scanner sc=new Scanner(System.in);
	ProductDaoImpl prodDao=new ProductDaoImpl();
	public void customerMenu() {
		while(true) {
		System.out.println("*********************Customer Menu*********************************************");
		System.out.println("                    1) View Products                                               ");
		System.out.println("                    2) View Product                                               ");
		System.out.println("                    3) Buy Product                                                ");
		System.out.println("                    4) Bill of Buy Product                                                ");
		System.out.println("                    5) Back                                                    ");
		System.out.println("******************************************************************************");
		System.out.println("Enter your choice");
		int choice= sc.nextInt();
		switch(choice) {
		case 1:
			prodDao.viewAllProducts();
			break;
		case 2:
			System.out.println("Enter the product name");
			String productName=sc.next();
			prodDao.viewProductByName(productName);
			break;
		case 3:
			System.out.println("Enter the product Id");
			int productId=sc.nextInt();
			prodDao.buyProduct(productId);
			break;
		case 4:
			prodDao.displayBuyProduct();
			break;
		case 5:
			ProductClient.main(null);
			
		default:
			System.out.println("Choose between 1-5");
		}
		}
	}
}
