package com.pms.dao.impl;

import java.util.ArrayList;
import java.util.Scanner;

import com.pms.dao.CustomerDao;
import com.pms.pojo.Customer;
import com.pms.pojo.Product;

public class CustomerDaoImpl implements CustomerDao {
	Scanner sc = new Scanner(System.in);

	ArrayList<Customer> custArray = new ArrayList<Customer>();

	@Override
	public void addCustomer() {
		// TODO Auto-generated method stub
		System.out.println("Enter the number of customer you want to add");
		int num = sc.nextInt();
		for (int i = 0; i < num; i++) {
			Customer cust = new Customer();
			System.out.println("Enter Customer Id");
			cust.setUid(sc.nextInt());
			System.out.println("Enter First name");
			cust.setFirstName(sc.next());
			System.out.println("Enter Last Name");
			cust.setLastName(sc.next());
			System.out.println("Enter Email Id");
			cust.setEmail(sc.next());
			System.out.println("Enter Password");
			cust.setPassword(sc.next());
			System.out.println("Enter Mobile number");
			cust.setMobileNumber(sc.nextInt());
			custArray.add(cust);
			System.out.println("Customer Added Successfully");
		}
	}

	@Override
	public void viewAllCustomers() {
		// TODO Auto-generated method stub
		if (!custArray.isEmpty()) {
			System.out.println("Customer Id\tFirst Name\tLast Name\tEmail\tPassword\tMobile Number");
			for (Customer c : custArray) {
				System.out.println(c.getUid() + "\t" + c.getFirstName() + "\t" + c.getLastName() + "\t" + c.getEmail()+"\t"+c.getPassword()+"\t"+c.getMobileNumber());
			}
		} else {
			System.out.println("Please enter some customer first");
		}
	}

	@Override
	public void viewCustomer(int uid) {
		// TODO Auto-generated method stub
		int k = 0;
		if (!custArray.isEmpty()) {
			System.out.println("Customer Id\tFirst Name\tLast Name\tEmail\tPassword\tMobile Number");
			for (Customer c : custArray) {
				if (c.getUid() == uid) {
					System.out.println(c.getUid() + "\t" + c.getFirstName() + "\t" + c.getLastName() + "\t" + c.getEmail()+"\t"+c.getPassword()+"\t"+c.getMobileNumber());
					k++;
				}
			}
			if (k == 0) {
				System.out.println("Sorry cannot find the customer. Please check customer Id again");
			}
		} else {
			System.out.println("Please enter some customer first");
		}
	}

	@Override
	public void updateCustomer(int uid) {
		// TODO Auto-generated method stub
		int k=0;
		if (!custArray.isEmpty()) {
			for (Customer c : custArray) {
				if (c.getUid() == uid) {
					System.out.println("What do you want to update 1)First Name 2)Password 3)Mobile Number");
					int choice = sc.nextInt();
					switch (choice) {
					case 1:
						System.out.println("Enter the updating First name");
						c.setFirstName(sc.next());
						System.out.println("Customer Name updated successfully");
						break;
					case 2:
						System.out.println("Enter the updating Password");
						c.setPassword(sc.next());
						System.out.println("Pasword updated successfully");
						break;
					case 3:
						System.out.println("Enter the updating mobile number");
						c.setMobileNumber(sc.nextInt());
						System.out.println("Mobile Number updated successfully");
						break;
					default:
						System.out.println("Choose between 1-3");
					}
					k++;
				} 
			}
			if (k == 0) {
				System.out.println("Sorry cannot find the customer. Please check customer Id again");
			}
		} else {
			System.out.println("Please enter some customer first");
		}
	}

	@Override
	public void deleteCustomer(int uid) {
		// TODO Auto-generated method stub
		int k=0;
		if (!custArray.isEmpty()) {
			for (Customer c : custArray) {
				if (c.getUid() == uid) {
					custArray.remove(c);
					System.out.println("Record Deleted Successfully");
				} 
				k++;
			}
			if (k == 0) {
				System.out.println("Sorry cannot find the customer. Please check customer Id again");
			}
		} else {
			System.out.println("Please enter some customer first");
		}
	}

}
