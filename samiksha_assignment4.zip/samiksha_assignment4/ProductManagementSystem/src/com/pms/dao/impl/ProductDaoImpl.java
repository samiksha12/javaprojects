package com.pms.dao.impl;

import java.util.ArrayList;
import java.util.Scanner;

import com.pms.dao.ProductDao;
import com.pms.pojo.Product;

public class ProductDaoImpl implements ProductDao {
	Scanner sc = new Scanner(System.in);

	ArrayList<Product> prodArray = new ArrayList<Product>();
	ArrayList<Product> buyProduct=new ArrayList<Product>();
	@Override
	public void addProduct() {
		// TODO Auto-generated method stub
		System.out.println("Enter the number of products you want to add");
		int num = sc.nextInt();
		for (int i = 0; i < num; i++) {
			Product prod = new Product();
			System.out.println("Enter Product Id");
			prod.setPid(sc.nextInt());
			System.out.println("Enter Product name");
			prod.setPname(sc.next());
			System.out.println("Enter Product quantity");
			prod.setQty(sc.nextInt());
			System.out.println("Enter Product Price");
			prod.setPrice(sc.nextInt());
			prodArray.add(prod);
			System.out.println("Item Added Successfully");
		}
	}

	@Override
	public void viewAllProducts() {
		// TODO Auto-generated method stub
		if (!prodArray.isEmpty()) {
			System.out.println("Product Id\tProduct Name\tQty\tPrice");
			for (Product p : prodArray) {
				System.out.println(p.getPid() + "\t" + p.getPname() + "\t" + p.getQty() + "\t" + p.getPrice());
			}
		} else {
			System.out.println("Please enter some product first");
		}
	}

	@Override
	public void viewProduct(int pid) {
		// TODO Auto-generated method stub
		int k = 0;
		if (!prodArray.isEmpty()) {
			System.out.println("Product Id\tProduct Name\tQty\tPrice");
			for (Product p : prodArray) {
				if (p.getPid() == pid) {
					System.out.println(p.getPid() + "\t" + p.getPname() + "\t" + p.getQty() + "\t" + p.getPrice());
					k++;
				}
			}
			if (k == 0) {
				System.out.println("Sorry cannot find the product. Please check product Id again");
			}
		} else {
			System.out.println("Please enter some product first");
		}
	}

	@Override
	public void updateProduct(int pid) {
		// TODO Auto-generated method stub
		int k=0;
		if (!prodArray.isEmpty()) {
			for (Product p : prodArray) {
				if (p.getPid() == pid) {
					System.out.println("What do you want to update 1)Product Name 2)Qty 3)Price");
					int choice = sc.nextInt();
					switch (choice) {
					case 1:
						System.out.println("Enter the updating product name");
						p.setPname(sc.next());
						System.out.println("Product Name updated successfully");
						break;
					case 2:
						System.out.println("Enter the updating product qty");
						p.setQty(sc.nextInt());
						System.out.println("Product Qty updated successfully");
						break;
					case 3:
						System.out.println("Enter the updating product price");
						p.setPrice(sc.nextInt());
						System.out.println("Product Price updated successfully");
						break;
					default:
						System.out.println("Choose between 1-3");
					}
					k++;
				} 
			}
			if (k == 0) {
				System.out.println("Sorry cannot find the product. Please check product Id again");
			}
		} else {
			System.out.println("Please enter some product first");
		}
	}

	@Override
	public void deleteProduct(int pid) {
		// TODO Auto-generated method stub
		int k=0;
		if (!prodArray.isEmpty()) {
			for (Product p : prodArray) {
				if (p.getPid() == pid) {
					prodArray.remove(p);
					System.out.println("Record Deleted Successfully");
				} 
				k++;
			}
			if (k == 0) {
				System.out.println("Sorry cannot find the product. Please check product Id again");
			}
		} else {
			System.out.println("Please enter some product first");
		}
	}

	@Override
	public void viewProductByName(String pname) {
		// TODO Auto-generated method stub
		int k = 0;
		if (!prodArray.isEmpty()) {
			System.out.println("Product Id\tProduct Name\tQty\tPrice");
			for (Product p : prodArray) {
				if (p.getPname().equals(pname)) {
					System.out.println(p.getPid() + "\t" + p.getPname() + "\t" + p.getQty() + "\t" + p.getPrice());
					k++;
				}
			}
			if (k == 0) {
				System.out.println("Sorry cannot find the product. Please check product Id again");
			}
		} else {
			System.out.println("Please enter some product first");
		}
	}

	@Override
	public void buyProduct(int pid) {
		// TODO Auto-generated method stub
		int k = 0;
		if (!prodArray.isEmpty()) {
			System.out.println("Product Id\tProduct Name\tQty\tPrice");
			for (Product p : prodArray) {
				if (p.getPid() == pid) {
					buyProduct.add(p);
					k++;
				}
			}
			if (k == 0) {
				System.out.println("Sorry cannot find the product. Please check product Id again");
			}
		} else {
			System.out.println("Please enter some product first");
		}
		
	}

	@Override
	public void displayBuyProduct() {
		// TODO Auto-generated method stub
		if (!buyProduct.isEmpty()) {
			System.out.println("Product Id\tProduct Name\tQty\tPrice");
			for (Product p : buyProduct) {
				System.out.println(p.getPid() + "\t" + p.getPname() + "\t" + p.getQty() + "\t" + p.getPrice());
			}
		} else {
			System.out.println("Please buy some product first");
		}
	}

}
