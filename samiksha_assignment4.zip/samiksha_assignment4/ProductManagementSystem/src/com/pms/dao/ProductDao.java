package com.pms.dao;

public interface ProductDao {
	void addProduct();
	
	void viewAllProducts();
	
	void viewProduct(int pid);
	
	void viewProductByName(String pname);
	
	void updateProduct(int pid);
	
	void deleteProduct(int pid);
	
	void buyProduct(int pid);
	
	void displayBuyProduct();
}
