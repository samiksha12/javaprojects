package com.pms.dao;

public interface CustomerDao {
	void addCustomer();

	void viewAllCustomers();

	void viewCustomer(int uid);

	void updateCustomer(int uid);

	void deleteCustomer(int uid);
}
