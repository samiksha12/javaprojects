package patternProgramming;

public class Pattern4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i = 0; i < 4; ++i) {// 4rows
			for (int j = 0; j < 5; ++j) {// 5column
				if (i == 0 || i == 3 || j == 0 || j == 4) {
					System.out.print("@");
				} else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
	}

}
