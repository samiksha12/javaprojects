package patternProgramming;

public class Pattern10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for (int i = 0; i < 3; ++i) {
			for (char j = 'a'; j <= 'f'; ++j) {
				System.out.print(j + " ");

			}
			System.out.println();
		}
	}

}
