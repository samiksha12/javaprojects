package patternProgramming;

public class Pattern8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		int f1=1;
//		int f2=3;
//		int f3=0;
//		int f4=0;
//		int f5=0;
//		System.out.print(f1+" "+f2+" ");
//		for(int i=1;i<50;++i) {
//			f3=f1+f2;
//			f4=f3+f1;
//			f5=f3+f2;
//			f1=f3;
//			f2=f4;
//			
//			if(f3 >50) {
//				break;
//			}
//			System.out.print(f3+" "+f4+" "+f5+" ");
//		}
//Output : 1 3 4 5 7 9
		int k=1;
		for(int i=0;i<5;++i) {
			for(int j=0;j<5;++j) {
				System.out.print(k+" ");
				k+=2;
			}
			System.out.println();
		}
		
		//Output : 1 3 5 7 9
	}

}
