package patternProgramming;

public class Pattern7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int k=1;
		for(int i=0;i<5;++i) {//5rows
			for(int j=1;j<=10;++j) {//10columns
				System.out.print(k+" ");
				++k;
			}
			System.out.println();
		}
	}

}
