package patternProgramming;

public class PascalPattern {
	public int factorial(int number) {
		if(number==0) {
			return 1;
		}
		return number * factorial(number-1);
	}
	public static void main(String[] args) {
		PascalPattern pp= new PascalPattern();
		// TODO Auto-generated method stub
		for(int i=0;i<7;++i) {
			for(int j=0;j<=i;++j) {
				int printNumber= pp.factorial(i)/(pp.factorial(i-j)*pp.factorial(j));
				System.out.print(printNumber+" ");
			}
			System.out.println();
		}
	}

}
