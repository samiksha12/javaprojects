package resturant.menu;

import java.util.Scanner;

public class BiryaniMenu {
	Scanner sc = new Scanner(System.in);
	int noOfPlates;
	int chickenPrice = 40;
	int muttonPrice = 60;
	int veggiePrice = 40;
	int chickenBill;
	int muttonBill;
	int veggieBill;
	static int biryaniBill;

	void biryaniMenu() {
		while (true) {
			System.out.println("1)Chicken Biryani : $40");
			System.out.println("2)Mutton Biryani : $60");
			System.out.println("3)Veggie Biryani : $40");
			System.out.println("4)Back");
			System.out.println("Enter your Biryani Choice");
			int biryaniChoice = sc.nextInt();
			switch (biryaniChoice) {
			case 1:
				billOfChickenBiryani();
				break;
			case 2:
				billOfMuttonBiryani();
				break;
			case 3:
				billOfVeggieBiryani();
				break;
			case 4:
				biryaniMenuBack();
				break;
			default:
				System.out.println("Choose between 1 to 3");
			}
		}
	}

	void billOfChickenBiryani() {
		System.out.println("How many plates do you want?");
		noOfPlates = sc.nextInt();
		chickenBill = noOfPlates * chickenPrice;
		biryaniBill = biryaniBill + chickenBill;
		System.out.println("Chicken Biryani qty: " + noOfPlates + " price: " + chickenBill + "\n");
	}

	void billOfMuttonBiryani() {
		System.out.println("How many plates do you want?");
		noOfPlates = sc.nextInt();
		muttonBill = noOfPlates * muttonPrice;
		biryaniBill = biryaniBill + muttonBill;
		System.out.println("Mutton Biryani qty: " + noOfPlates + " price: " + muttonBill + "\n");
	}

	void billOfVeggieBiryani() {
		System.out.println("How many plates do you want?");
		noOfPlates = sc.nextInt();
		veggieBill = noOfPlates * veggiePrice;
		biryaniBill = biryaniBill + veggieBill;
		System.out.println("Veggie Biryani qty: " + noOfPlates + " price: " + veggieBill + "\n");
	}

	void biryaniMenuBack() {
		
		ResturantMenu.main(null);
	}
}
