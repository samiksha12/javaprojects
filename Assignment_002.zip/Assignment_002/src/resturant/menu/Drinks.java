package resturant.menu;

import java.util.Scanner;

public class Drinks {
	Scanner sc = new Scanner(System.in);
	int quantity;
	int choice;
	int pepsiPrice = 5;
	int pepsiBill;
	int cokePrice = 5;
	int cokeBill;
	int teaPrice = 3;
	int teaBill;
	int coffeePrice = 3;
	int coffeeBill;
	static int drinksBill = 0;

	void drinksMenu() {
		while (true) {
			System.out.println("1)Soft-Drinks");
			System.out.println("2)Hot-Drinks");
			System.out.println("3)Back");
			System.out.println("Enter your Drinks Choice");
			int drinksChoice = sc.nextInt();
			switch (drinksChoice) {
			case 1:
				softDrinkMenu();
				break;
			case 2:
				hotDrinkMenu();
				break;
			case 3:
				drinksMenuBack();
				break;
			default:
				System.out.println("Choose between 1 or 2");
			}
		}
	}

	void softDrinkMenu() {
		while (true) {
		System.out.println("1)Pepsi");
		System.out.println("2)Coke");
		System.out.println("3)Back");
		System.out.println("Enter your Soft Drinks Choice");
		choice = sc.nextInt();
		
			switch (choice) {
			case 1: {
				System.out.println("How many quantities do you want?");
				quantity = sc.nextInt();
				pepsiBill = quantity * pepsiPrice;
				drinksBill = drinksBill + pepsiBill;
				System.out.println("Pepsi qty: " + quantity + " price: " + pepsiBill + "\n");
				break;
			}
			case 2: {
				System.out.println("How many quantities do you want?");
				quantity = sc.nextInt();
				cokeBill = quantity * cokePrice;
				drinksBill = drinksBill + cokeBill;
				System.out.println("Coke qty: " + quantity + " price: " + cokeBill + "\n");
				break;
			}
			case 3: {
				drinksMenu();
				break;
			}
			default:
				System.out.println("Choose between 1 or 2");

			}
		}

	}

	void hotDrinkMenu() {
		while (true) {
		System.out.println("1)Tea");
		System.out.println("2)Coffee");
		System.out.println("3)Back");
		System.out.println("Enter your Hot Drinks Choice");
		choice = sc.nextInt();
		
			switch (choice) {
			case 1: {
				System.out.println("How many quantities do you want?");
				quantity = sc.nextInt();
				teaBill = quantity * teaPrice;
				drinksBill = drinksBill + teaBill;
				System.out.println("Tea qty: " + quantity + " price: " + teaBill + "\n");
				break;
			}
			case 2: {
				System.out.println("How many quantities do you want?");
				quantity = sc.nextInt();
				coffeeBill = quantity * coffeePrice;
				drinksBill = drinksBill + coffeeBill;
				System.out.println("Coffee qty: " + quantity + " price: " + coffeeBill + "\n");
				break;
			}
			case 3: {
				drinksMenu();
				break;
			}
			default:
				System.out.println("Choose between 1 or 2");

			}
		}
	}

	void drinksMenuBack() {
		ResturantMenu.main(null);
	}
}
