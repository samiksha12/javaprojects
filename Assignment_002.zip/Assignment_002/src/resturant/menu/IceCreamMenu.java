package resturant.menu;

import java.util.Scanner;

public class IceCreamMenu {
	Scanner sc = new Scanner(System.in);
	int quantity;
	int vanillaPrice = 5;
	int butterPrice = 6;
	int vanillaBill;
	int butterBill;
	static int iceCreamBill;

	void iceCreamMenu() {
		while (true) {
			System.out.println("1)Vanilla");
			System.out.println("2)ButterScotch");
			System.out.println("3)Back");
			System.out.println("Enter your Icecream Choice");
			int icecreamChoice = sc.nextInt();
			switch (icecreamChoice) {
			case 1:
				billOfVanilla();
//			iceCreamMenu();
				break;
			case 2:
				billOfButter();
//			iceCreamMenu();
				break;
			case 3:
				iceCreamMenuBack();
				break;
			default:
				System.out.println("Choose between 1 or 2");

			}
		}
	}

	void billOfVanilla() {
		System.out.println("How many quantities do you want?");
		quantity = sc.nextInt();
		vanillaBill = quantity * vanillaPrice;
		iceCreamBill = iceCreamBill + vanillaBill;
		System.out.println("Vanilla Icecream qty: " + quantity + " price: " + vanillaBill + "\n");
	}

	void billOfButter() {
		System.out.println("How many quantities do you want?");
		quantity = sc.nextInt();
		butterBill = quantity * butterPrice;
		iceCreamBill = iceCreamBill + butterBill;
		System.out.println("ButterScotch Icecream qty: " + quantity + " price: " + butterBill + "\n");
	}

	void iceCreamMenuBack() {
		ResturantMenu.main(null);
	}
}
