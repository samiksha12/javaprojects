package programFundamentalAssignment;

public class PrimeNumbers1To100 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String primeNumber = "";
		for (int i = 2; i <= 100; ++i) {
			int count = 0;
			for (int j = i; j >= 2; --j) {
				if (i % j == 0) {
					count++;
				}
			}
			if (count == 1) {
				primeNumber = primeNumber + "" + i+" ";
			}
		}
		System.out.println(primeNumber);

		System.out.println();
		System.out.println("**********************************************");
		System.out.println();

		for (int i = 2; i <= 100; ++i) {
			if (i % 2 == 0 || i % 3 == 0 || i % 5 == 0 || i % 7 == 0) {
				if (i == 2 || i == 3 || i == 5 || i == 7) {
					System.out.print(i + " ");
				}
			} else {
				System.out.print(i + " ");
			}
		}
	}

}
