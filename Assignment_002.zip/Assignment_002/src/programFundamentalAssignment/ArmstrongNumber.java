package programFundamentalAssignment;

import java.util.Scanner;

public class ArmstrongNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your number");
		int num = sc.nextInt();
		int result = 0;
		int reminder = 0;
		int originalNumber = num;
		while (num != 0) {
			reminder = num % 10;

			result = result + reminder * reminder * reminder;

			num = num / 10;
		}

		if (originalNumber == result) {
			System.out.println(originalNumber + " is a Armstrong number");

		} else {
			System.out.println(originalNumber + " is not a Armstrong number");
		}
	}

}
