package programFundamentalAssignment;

import java.util.Scanner;

public class CalculateFactorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your number");
		int num = sc.nextInt();
		int factorial =1;
		for(int i=num; i>=1;--i) {
			factorial = factorial * i;
		}
		System.out.println("The factorial of "+num+" is "+factorial);
	}

}
