package programFundamentalAssignment;
import java.util.Scanner;

public class CheckPrimeNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your number");
		int num = sc.nextInt();
		int count=0;
		if(num==0 || num==1) {
			System.out.println(num+" not prime number");
		}else {
			for(int i=2;i<=num;++i) {
				if(num%i==0) {
					count++;
				}
			}
		}
		if(count==1) {
			System.out.println(num+" is prime number");
		}else {
			System.out.println(num+" not prime number");
		}
	}

}
