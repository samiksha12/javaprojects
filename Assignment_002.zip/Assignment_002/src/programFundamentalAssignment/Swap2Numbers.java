package programFundamentalAssignment;

public class Swap2Numbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Swapping with a temperory variable");
		int f1 = 100;
		int f2 = 200;
		System.out.println("Before Swapping numbers are " + f1 + " " + f2);
		int temp = 0;
		temp = f1;
		f1 = f2;
		f2 = temp;
		System.out.println("After Swapping numbers are " + f1 + " " + f2);
		System.out.println();
		System.out.println("***************************************");
		System.out.println();
		f1 = 100;
		f2 = 200;
		System.out.println("Swapping without a temperory variable");
		System.out.println("Before Swapping numbers are " + f1 + " " + f2);
		f1 = f1 + f2;
		f2 = f1 - f2;
		f1 = f1 - f2;
		System.out.println("After Swapping numbers are " + f1 + " " + f2);

	}

}
