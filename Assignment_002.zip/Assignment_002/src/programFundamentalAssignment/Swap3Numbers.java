package programFundamentalAssignment;

public class Swap3Numbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Swap 3 numbers with temp variable");
		int f1 = 100;
		int f2 = 200;
		int f3 = 300;
		int temp = 0;
		System.out.println("Before swapping numbers f1=" + f1 + " f2=" + f2 + " f3=" + f3);
		temp = f1;
		f1 = f3;
		f3 = f2;
		f2 = temp;
		System.out.println("After swapping numbers f1=" + f1 + " f2=" + f2 + " f3=" + f3);
		System.out.println();
		System.out.println("***************************************");
		System.out.println();
		System.out.println("Swap 3 numbers without temp variable");
		f1 = 100;
		f2 = 200;
		f3 = 300;
		System.out.println("Before swapping numbers f1=" + f1 + " f2=" + f2 + " f3=" + f3);
		f1 = f1 + f2 + f3;
		f2 = f1 - f2 - f3;
		f3 = f1 - f2 - f3;
		f1 = f1 - f2 - f3;
		System.out.println("After swapping numbers f1=" + f1 + " f2=" + f2 + " f3=" + f3);
	}

}
