
public class DiscountCalculator {

	public static void main(String[] args) {
		int noOfPizza = 2;
		int prizeOfPizza = 300;
		int discountPercent = 20;
		float discountValue;
		float payPrize;
		discountValue = (discountPercent * (noOfPizza * prizeOfPizza)) / 100;
		payPrize = (noOfPizza * prizeOfPizza) - discountValue;
		System.out.println("The total bill after discount is " + payPrize);

	}

}
