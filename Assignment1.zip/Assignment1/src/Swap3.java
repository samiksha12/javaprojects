
public class Swap3 {

	public static void main(String[] args) {
		System.out.println("Swap 3 numbers with temp variable");
		int f1 = 100;
		int f2 = 200;
		int f3 = 300;
		int temp = 0;
		System.out.println("Before swapping numbers f1=" + f1 + " f2=" + f2 + " f3=" + f3);
		temp = f1;
		f1 = f2;
		f2 = f3;
		f3 = temp;
		System.out.println("After swapping numbers f1=" + f1 + " f2=" + f2 + " f3=" + f3);
		System.out.println("\nSwap 3 numbers with temp variable");
		System.out.println("Before swapping numbers f1=" + f1 + " f2=" + f2 + " f3=" + f3);
		f1 = f1 + f2 + f3;
		f2 = f1 - f2 - f3;
		f3 = f1 - f2 - f3;
		f1 = f1 - f2 - f3;
		System.out.println("After swapping numbers f1=" + f1 + " f2=" + f2 + " f3=" + f3);
	}

}
