
public class Swap4 {

	public static void main(String[] args) {
		System.out.println("Swap 4 numbers with temp variable");
		int f1 = 100;
		int f2 = 200;
		int f3 = 300;
		int f4 = 400;
		int temp = 0;
		System.out.println("Before swapping numbers f1=" + f1 + " f2=" + f2 + " f3=" + f3 + " f4=" + f4);
		temp = f1;
		f1 = f2;
		f2 = f3;
		f3 = f4;
		f4 = temp;
		System.out.println("After swapping numbers f1=" + f1 + " f2=" + f2 + " f3=" + f3 + " f4=" + f4);
		System.out.println("\nSwap 4 numbers with temp variable");
		System.out.println("Before swapping numbers f1=" + f1 + " f2=" + f2 + " f3=" + f3 + " f4=" + f4);
		f1 = f1 + f2 + f3 + f4;
		f2 = f1 - f2 - f3 - f4;
		f3 = f1 - f2 - f3 - f4;
		f4 = f1 - f2 - f3 - f4;
		f1 = f1 - f2 - f3 - f4;
		System.out.println("After swapping numbers f1=" + f1 + " f2=" + f2 + " f3=" + f3 + " f4=" + f4);
	}

}
